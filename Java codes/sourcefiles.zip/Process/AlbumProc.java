package Process;

import java.util.List;
import java.util.Scanner;

import DataAccess.AlbumDAO;
import DataTransfer.AlbumDTO;
import DataTransfer.ArtistDTO;
import DataTransfer.SongDTO;

/**
 * Create this object in the main and use this class's method. In this class,
 * After receiving user input within the method, perform the query using the DAO
 * object.
 * 
 * @author Inryu Shin
 *
 */
public class AlbumProc {
	// ��� ����
	AlbumDAO dao;
	static public Scanner input = new Scanner(System.in);

	/**
	 * default constructor
	 */
	public AlbumProc() {
		dao = new AlbumDAO();

	}

	/**
	 * Take album_name, artist_sn as parameter and take input from user of
	 * release_date. Create DTO object using those values and call the DAO object's
	 * insertAlbum function using DTO as parameter. *
	 * 
	 * @param album_name
	 * @param artist_sn
	 */
	public void insertAlbum(String album_name, int artist_sn) { // ���ڷ� �̸��� ����

		System.out.println("\nEnter album information.");

		// System.out.print("name : ");
		// String name = input.nextLine();
		System.out.print("�� release date : ");
		String release_date = input.nextLine();

		// Artistdto ��ü ���� (�Է� ���� ���� ������ �̿�)
		AlbumDTO album = new AlbumDTO(album_name, release_date, artist_sn);

		boolean r = dao.insertAlbum(album); // �Է¹��� ������ �߰�

		if (r) {
			System.out.println("Input is entered successfully.");
		} else {
			System.out.println("Failed. Input is not entered");
		}

	}

	/**
	 * Take album_name as parameter and and call the DAO object's IsExists function.
	 * 
	 * @param album_name
	 * @return
	 */
	public int IsExists(String album_name) {
		int n = dao.IsExists(album_name);
		int result;

		if (n == 0)
			result = 0;
		else
			result = 1;

		return result;

	}

	/**
	 * Take album_name as parameter and call the DAO object's selectSN function.
	 * 
	 * @param album_name
	 * @return
	 */
	public int selectSN(String album_name) {
		int n = dao.selectSN(album_name);
		return n;
	}

	/**
	 * Call the DAO object's getAlbumList function into List<AlbumDTO> list and then
	 * print that list.
	 */
	public void showAlbumList() {

		List<AlbumDTO> list = dao.getAlbumList();

		System.out.println("\n                                <Album List>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("album_sn\t  name \t\t\trelease_date\tartist_sn\t\t");
			System.out.println("============================================================================");

			for (AlbumDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("����� �����Ͱ� �����ϴ�. ");
		}
		System.out.println("============================================================================");
	}

	/**
	 * Take input from user of album_sn and call the DAO object's deleteAlbum(sn)
	 * function using input value.
	 */
	public void deleteAlbum() {

		System.out.print("�� Enter album_sn of Album you want to delete :  ");
		int sn = input.nextInt();
		System.out.println("\n\n");
		AlbumDTO dto = dao.getAlbum(sn);
		if (dto != null) {
			dto.printInfo();

			System.out.print("�� Are you sure you want to delete it?(Y/N) : ");
			input.nextLine();
			String ans = input.nextLine();
			if (ans.equalsIgnoreCase("y")) {
				boolean r = dao.deleteAlbum(sn);

				if (r) {
					System.out.println("Album [ " + sn + " ] 's information has been deleted successfully.");
				} else {
					System.out.println("Failed. Aritst [ \"+sn+\" ] 's information has been not deleted.");
				}
			} else {
				System.out.println("Deletion operation canceled.");
			}
		} else {

			System.out.println("Enter Correct artist_sn");

		}
	}

}
