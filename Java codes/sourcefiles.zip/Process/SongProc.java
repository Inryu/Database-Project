package Process;

import java.util.List;
import java.util.Scanner;

import DataAccess.SongDAO;
import DataTransfer.AlbumDTO;
import DataTransfer.ArtistDTO;
import DataTransfer.SongDTO;
/**
 * Create this object in the main and use this class's method. In this class,
 * After receiving user input within the method, perform the query using the DAO
 * object.
 * 
 * @author Inryu Shin
 *
 */
public class SongProc {
	// ��� ����
	SongDAO dao;
	static public Scanner input = new Scanner(System.in);

	/**
	 * default constructor
	 */
	public SongProc() {
		dao = new SongDAO();

	}

	/**
	 * Take song_title, album_sn, artist_sn as parameter and take input from user of genre.
	 * Create DTO object using those values and call the DAO object's
	 * insertSong function using DTO as parameter.
	 * @param song_title
	 * @param album_sn
	 * @param artist_sn
	 */
	public void insertSong(String song_title, int album_sn, int artist_sn) { // ���ڷ� �̸��� ����

		System.out.println("\nEnter Song information.");

		System.out.print("�� genre : ");
		String genre = input.nextLine();

		// SongDTO ��ü ���� (�Է� ���� ���� ������ �̿�)
		SongDTO song = new SongDTO(song_title, genre, album_sn, artist_sn);

		boolean r = dao.insertSong(song); // �Է¹��� ������ �߰�

		if (r) {
			System.out.println("Input is entered successfully.");
		} else {
			System.out.println("Failed. Input is not entered");
		}

	}
	/**
	 *  Take song_title as parameter and and call the DAO object's IsExists function.
	 * @param song_title
	 * @return
	 */
	public int IsExists(String song_title) {
		int n = dao.IsExists(song_title);
		int result;

		if (n == 0)
			result = 0;
		else
			result = 1;

		return result;

	}

	/**
	 * Call the DAO object's getSongList function into List<SongDTO>list and then print that list.
	 */
	public void showSongList() {

		List<SongDTO> list = dao.getSongList();

		System.out.println("\n                                <Song List>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("song_sn\t\t title\t\t\tgenre\t  album_sn\tartist_sn");
			System.out.println("============================================================================");

			for (SongDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("no data. ");
		}
		System.out.println("============================================================================");
	}
	
	
	/**
	 * Call the DAO object's getjoinSongList function into List<SongDTO>list by using parameter and then print that list.
	 * @param artist_name
	 * @param album_name
	 */
	public void showjoinSongList(String artist_name, String album_name) {

		List<SongDTO> list = dao.getjoinSongList(artist_name, album_name);

		System.out.println("\n                                <Song List>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("\t\t\t title\t\t\t\t   genre\t");
			System.out.println("============================================================================");

			for (SongDTO dto : list) {
				dto.printDTO();
			}

		} else {
			System.out.println("no data. ");
		}
		System.out.println("============================================================================");
	}

	/**
	 * Take input from user of song_sn and call the DAO object's
	 * deleteSong(sn) function using input value.
	 */
	public void deleteSong() {

		System.out.print("�� Enter song_sn of Song you want to delete :  ");
		int sn = input.nextInt();
		System.out.println("\n\n");
		SongDTO dto = dao.getSong(sn);
		if (dto != null) {
			dto.printInfo();

			System.out.print("�� Are you sure you want to delete it?(Y/N) : ");
			input.nextLine();
			String ans = input.nextLine();
			if (ans.equalsIgnoreCase("y")) {
				boolean r = dao.deleteSong(sn);

				if (r) {
					System.out.println("Song [ " + sn + " ] 's information has been deleted successfully.");
				} else {
					System.out.println("Failed. Aritst [ \"+sn+\" ] 's information has been not deleted.");
				}
			} else {
				System.out.println("Deletion operation canceled.");
			}
		} else {

			System.out.println("Enter Correct artist_sn");

		}
	}

}
