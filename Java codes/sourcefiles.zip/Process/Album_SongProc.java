package Process;

import java.util.List;
import java.util.Scanner;

import DataAccess.Album_SongDAO;
import DataTransfer.AlbumDTO;
import DataTransfer.Album_SongDTO;

/**
 * Create this object in the main and use this class's method. In this class,
 * After receiving user input within the method, perform the query using the DAO
 * object.
 * 
 * @author Inryu Shin
 *
 */
public class Album_SongProc {

	Album_SongDAO dao; // ArtistDAO�� ��������� ����
	static public Scanner input = new Scanner(System.in);

	/**
	 * default constructor
	 */
	public Album_SongProc() {
		dao = new Album_SongDAO();

	}

	/**
	 * Call the DAO object's getView function into List Album_SongDTO list and then
	 * print that list.
	 */
	public void showView() {
		List<Album_SongDTO> list = dao.getVIEW();

		System.out.println("\n                                 <VIEW>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("   name\t\t\t  title \t\t\tgenre");
			System.out.println("============================================================================");

			for (Album_SongDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("no data. ");
		}
		System.out.println("============================================================================");

	}
	

	/**
	 * Call the DAO object's selectGenre function into List Album_SongDTO list and then
	 * print that list.
	 * @param genre : Album genre
	 */
	public void showbyGenre(String genre) {
		List<Album_SongDTO> list = dao.selectGenre(genre);

		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("   name\t\t\t  title \t\t\tgenre");
			System.out.println("============================================================================");

			for (Album_SongDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("no data. ");
		}
		System.out.println("============================================================================");
	}

}
