package Process;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import DataAccess.ArtistDAO;
import DataTransfer.ArtistDTO;

/**
 * Create this object in the main and use this class's method. In this class,
 * After receiving user input within the method, perform the query using the DAO
 * object.
 * 
 * @author Inryu Shin
 *
 */
public class ArtistProc {

	// �������
	// int isExists=2; //�̸� ���翩�� Ȯ���ϴ� flag ����
	ArtistDAO dao; // ArtistDAO�� ��������� ����
	static public Scanner input = new Scanner(System.in);

	/**
	 * default constructor
	 */
	public ArtistProc() {
		dao = new ArtistDAO();

	}

	/**
	 * Take artist_name as parameter and take input from user of debut date, type,
	 * gender. Create DTO object using those values and call the DAO object's
	 * insertArtist function using DTO.
	 * 
	 * @param artist_name
	 */
	public void insertArtist(String artist_name) { // ���ڷ� �̸��� ����

		System.out.println("\nEnter artist information.");

		// System.out.print("name : ");
		// String name = input.nextLine();
		System.out.print("�� debut date : ");
		String debut_date = input.nextLine();
		System.out.print("�� type : ");
		String type = input.nextLine();
		System.out.print("�� gender: ");
		String gender = input.nextLine();

		// Artistdto ��ü ���� (�Է� ���� ���� ������ �̿�)
		ArtistDTO artist = new ArtistDTO(artist_name, debut_date, type, gender);

		boolean r = dao.insertArtist(artist); // �Է¹��� ������ �߰�

		if (r) {
			System.out.println("Input is entered successfully.");
		} else {
			System.out.println("Failed. Input is not entered");
		}

	}

	/**
	 *
	 * Take artist_name as parameter and and call the DAO object's IsExists
	 * function.
	 * 
	 * @param artist_name
	 */

	public int IsExists(String artist_name) {
		int n = dao.IsExists(artist_name);
		int result;

		if (n == 0)
			result = 0;
		else
			result = 1;

		return result;

	}

	/**
	 * Take artist_name as parameter and call the DAO object's selectSN function.
	 * 
	 * @param artist_name
	 * @return
	 */
	public int selectSN(String artist_name) {
		int n = dao.selectSN(artist_name);
		return n;
	}

	/**
	 * Call the DAO object's getArtistsList function into List<ArtistDTO> list and
	 * then print that list.
	 */
	public void showAritstList() {

		List<ArtistDTO> list = dao.getArtistList();

		System.out.println("                                <Artist List>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("artist_sn\t  name \t\tdebut_date\ttype\t\tgender");
			System.out.println("============================================================================");

			for (ArtistDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("����� �����Ͱ� �����ϴ�. ");
		}
		System.out.println("============================================================================");
	}

	/**
	 * 
	 * Using type parameter , Call the DAO object's gettypeAtistsList function into
	 * List<ArtistDTO> list and then print that list.
	 *
	 * @param type
	 */
	public void typeAritstList(String type) {

		List<ArtistDTO> list = dao.gettypeArtist(type);

		System.out.println("                                <Artist List>");
		System.out.println("============================================================================");
		if (list != null && list.size() > 0) {
			System.out.println("artist_sn\t  name \t\tdebut_date\ttype\t\tgender");
			System.out.println("============================================================================");

			for (ArtistDTO dto : list) {
				System.out.println(dto);
			}

		} else {
			System.out.println("����� �����Ͱ� �����ϴ�. ");
		}
		System.out.println("============================================================================");
	}

	/**
	 * Take input from user and create DTO object using those input values and call
	 * the DAO object's updateArtist function using DTO.
	 */
	public void updateArtist() {

		System.out.print("�� Enter artist_sn you want to update : ");
		int current_artist_sn = input.nextInt();
		input.nextLine();

		ArtistDTO dto = dao.getArtist(current_artist_sn);

		if (dto != null) {

			System.out.println("");
			dto.printInfo();

			System.out.print("�� artist_sn : ");
			int artist_sn = input.nextInt();
			input.nextLine();
			System.out.print("�� name : ");
			String name = input.nextLine();
			System.out.print("�� debut date : ");
			String debut_date = input.nextLine();
			System.out.print("�� type : ");
			String type = input.nextLine();
			System.out.print("�� gender : ");
			String gender = input.nextLine();

			dto = new ArtistDTO(artist_sn, name, debut_date, type, gender);

			boolean r = dao.updateArtist(dto, current_artist_sn);

			if (r) {

				System.out.println("The artist's information has been modified as follows.");
				dto.printInfo();

			} else {
				System.out.println("The artist's information has not been modified normally.");
			}

		} else {

			System.out.println("Enter correct artist_sn");

		}
	}

	/**
	 * Call the DAO object's updateTransaction function by using parameter value.
	 * 
	 * @param current_artist_sn
	 * @param updated_artist_sn
	 * @throws SQLException
	 */
	public void updateTransaction(int current_artist_sn, int updated_artist_sn) throws SQLException {
		dao.updateTransaction(current_artist_sn, updated_artist_sn);
	}

	/**
	 * Take input from user of artist_sn and call the DAO object's deleteArtist(sn)
	 * function using input value.
	 */
	public void deleteArtist() {

		System.out.print("�� Enter artist_sn of Artist you want to delete :  ");
		int sn = input.nextInt();
		System.out.println("\n\n");
		ArtistDTO dto = dao.getArtist(sn);
		if (dto != null) {
			dto.printInfo();

			System.out.print("�� Are you sure you want to delete it?(Y/N) : ");
			input.nextLine();
			String ans = input.nextLine();
			if (ans.equalsIgnoreCase("y")) {
				boolean r = dao.deleteArtist(sn);

				if (r) {
					System.out.println("Aritst [ " + sn + " ] 's information has been deleted successfully.");
				} else {
					System.out.println("Failed. Aritst [ \"+sn+\" ] 's information has been not deleted.");
				}
			} else {
				System.out.println("Deletion operation canceled.");
			}
		} else {

			System.out.println("Enter correct artist_sn");

		}
	}

}
