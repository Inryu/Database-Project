import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import Process.AlbumProc;
import Process.Album_SongProc;
import Process.ArtistProc;
import Process.SongProc;

/**
 * Song Management program continues until user enter number 6.
 * 
 * @author Inryu Shin
 *
 */
public class Main {

	static public Scanner input = new Scanner(System.in);

	public static void main(String[] args) throws SQLException {

		// Proc ��ü ����

		ArtistProc artistProc = new ArtistProc();
		AlbumProc albumProc = new AlbumProc();
		SongProc songProc = new SongProc();
		Album_SongProc album_songProc= new Album_SongProc();

		int num = 0;
		while (true) {
			System.out.println("\n\n\n                               �� Song Management ��");
			System.out.println("============================================================================");
			System.out.println(" 1. Print All  2. INSERT  3. UPDATE  4. DELETE   5. SELECT    6. End program");
			System.out.println("============================================================================");

			try {
				System.out.print("�� Select number : ");
				num = input.nextInt();
				input.nextLine();
				if (!(num >= 1 && num <= 6)) {
					throw new InputMismatchException();
				}

			} catch (InputMismatchException e) {
				System.out.println("Wrong number");
			}

			if (num == 1) {
				System.out.println("");
				artistProc.showAritstList();
				albumProc.showAlbumList();
				songProc.showSongList();
			} else if (num == 2) {

				// 1. ���� �̸� �Է�

				System.out.print("\n�� Artist name : ");
				String artist_name = input.nextLine();

				// 1-1.������ �������� ������
				if (artistProc.IsExists(artist_name) == 0) {
					// ������ debut date, type, gender �ޱ�
					artistProc.insertArtist(artist_name);
				}

				// 1-2.������ �����ϸ�
				else if (artistProc.IsExists(artist_name) == 1) {
				}
				// 2. �ٹ� �Է�
				// �Է��� artist �̸����� artist_sn �˾Ƴ���
				int artist_sn = artistProc.selectSN(artist_name);

				System.out.print("�� Album name : ");
				String album_name = input.nextLine();

				// 2-1.�ٹ��� �������� ������
				if (albumProc.IsExists(album_name) == 0) {
					// �ٹ��� release date �ޱ�
					albumProc.insertAlbum(album_name, artist_sn);
				}

				// 2-2.�ٹ��� �����ϸ�
				else if (albumProc.IsExists(album_name) == 1) {
				}

				// 3.�뷡 �Է�
				// �Է��� artist �̸����� artist_sn �˾Ƴ���
				int album_sn = albumProc.selectSN(album_name);

				System.out.print("�� Song name : ");
				String song_title = input.nextLine();

				// 3-1. �뷡�� �������� ������
				if (songProc.IsExists(song_title) == 0) {
					// �ٹ��� release date �ޱ�
					songProc.insertSong(song_title, album_sn, artist_sn);
				}

				// 3-2.�뷡�� �����ϸ�
				else if (albumProc.IsExists(album_name) == 1) {
					System.out.println("The Song already exists.");
				}

			} else if (num == 3) {

				System.out.println("\n\n============================================================================");
				System.out.println("             1. Artist                                2. Album              ");
				System.out.println("============================================================================");

				try {
					System.out.print("�� Which table do you want to handle? : ");
					num = input.nextInt();
					input.nextLine();
					if (!(num >= 1 && num <= 2)) {
						throw new InputMismatchException();
					}

				} catch (InputMismatchException e) {
					System.out.println("Wrong number");
				}

				if (num == 1) {
					System.out.println("");
					artistProc.showAritstList();
					artistProc.updateArtist();

				}

				// transaction Ȱ��
				if (num == 2) {
					System.out.println("");
					albumProc.showAlbumList();
					System.out.print("�� Enter the artist_sn you want to update : ");
					int current_artist_sn = input.nextInt();
					System.out.print("�� What value would you like to replace artist_sn? : ");
					int updated_artist_sn = input.nextInt();
					input.nextLine();
					artistProc.updateTransaction(current_artist_sn, updated_artist_sn);

					System.out.println("");
					albumProc.showAlbumList();
					artistProc.showAritstList();

				}

			} else if (num == 4) {

				System.out.println("\n\n============================================================================");
				System.out.println(" 1. Artist                       2. Album                           3. Song ");
				System.out.println("============================================================================");

				try {
					System.out.print("�� Which table do you want to handle? : ");
					num = input.nextInt();
					input.nextLine();
					if (!(num >= 1 && num <= 3)) {
						throw new InputMismatchException();
					}

				} catch (InputMismatchException e) {
					System.out.println("Wrong number");
				}

				if (num == 1) {
					System.out.println("");
					artistProc.showAritstList();
					artistProc.deleteArtist();
				} else if (num == 2) {
					System.out.println("");
					albumProc.showAlbumList();
					albumProc.deleteAlbum();
				} else if (num == 3) {
					System.out.println("");
					songProc.showSongList();
					songProc.deleteSong();
				}

			} else if (num == 5) {

				System.out.println("\n\n============================================================================");
				System.out.println("      1. Artist               2. Join Table             3. Using View");
				System.out.println("============================================================================");

				try {
					System.out.print("�� Which table do you want to handle? : ");
					num = input.nextInt();
					input.nextLine();
					if (!(num >= 1 && num <= 3)) {
						throw new InputMismatchException();
					}

				} catch (InputMismatchException e) {
					System.out.println("Wrong number");
				}

				if (num == 1) {
					System.out.println("\n\n============================================================================");
					System.out.println("                       1. group                      2. solo");
					System.out.println("============================================================================");
					
					try {
						System.out.print("�� Select the type you want to see : ");
						num = input.nextInt();
						input.nextLine();
						if (!(num >= 1 && num <= 2)) {
							throw new InputMismatchException();
						}

					} catch (InputMismatchException e) {
						System.out.println("Wrong number");
					}
						if(num==1) { 
							System.out.println("\n\n");
							artistProc.typeAritstList("group");		
	
						}
						else if(num==2) {
							System.out.println("\n\n");
							artistProc.typeAritstList("solo");
						
						}
				}
					

				else if (num == 2) {//Join Table
					System.out.println("\n\n");
					artistProc.showAritstList();
					albumProc.showAlbumList();
					System.out.println("If you choose Artist's name and Album name  ");
					System.out.println("then you can see song list in that Artist's Album ");
					System.out.print("�� Enter the Artist's name : ");
					String artist_name=input.nextLine();
					System.out.print("�� Enter the Album name : ");
					String album_name=input.nextLine();
					System.out.println("\n\n");
					songProc.showjoinSongList(artist_name, album_name);
		
										
					
					
				} else if (num == 3) {//Using View

					album_songProc.showView();
					System.out.print("�� Which genre do you want to search in ? : ");
					String genre=input.nextLine();
					System.out.println("\n\n");
					album_songProc.showbyGenre(genre);

					
					
				}

			} else if (num == 6) {
				System.out.println("\n\n============================================================================");
				System.out.println("                                �� Program END ��");
				System.out.println("============================================================================");
				break;

			}

		}

	}

	}

