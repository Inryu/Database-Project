package DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DataTransfer.AlbumDTO;
import DataTransfer.SongDTO;

/**
 * Data Access Object Classes that connect to a database and perform operations
 * such as input , modification, deletion, or query
 * 
 * @author Inryu Shin
 *
 */
public class SongDAO {

	private static Connection conn = null;
	private static Statement Stmt = null;
	private static ResultSet rs;
	private PreparedStatement pstmt;

	/**
	 * default constructor
	 */
	public SongDAO() {

	}

	/**
	 * Construct a connection using initialized userID, userPW, dbName, url.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private void getConnection() throws ClassNotFoundException, SQLException {
		if (conn == null) { // Connection��ü ������

			String userID = "dbuser";
			String userPW = "dbpwd";
			String dbName = "dbprj";
			String url = "jdbc:mysql://localhost:3306/" + dbName + "?&serverTimezone=UTC";

			conn = DriverManager.getConnection(url, userID, userPW);

		}
	}

	/**
	 * Take SongDTO as a parameter and execute insert query.
	 * 
	 * @param SongDTO artist
	 * @return boolean
	 */
	public boolean insertSong(SongDTO song) {

		boolean result = false;

		try {
			getConnection();

			String query = "INSERT INTO Song (title, genre, album_sn, artist_sn) VALUES(?,?,?,?)";

			PreparedStatement pstmt = conn.prepareStatement(query);

			pstmt.setString(1, song.getTitle());
			pstmt.setString(2, song.getGenre());
			pstmt.setInt(3, song.getAlbum_sn());
			pstmt.setInt(4, song.getArtist_sn());

			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception : insertSong " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Take the song_title of the Song as a parameter and check if the data with
	 * that title exists on the Song table.
	 * 
	 * @param String song_title
	 * @return 0(not exists) 1(exists)
	 */
	public int IsExists(String song_title) {

		int result = 2;
		int n = 2;

		try {
			getConnection();

			String query = "SELECT count(*) FROM Song WHERE title=?";

			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, song_title);

			ResultSet r = pstmt.executeQuery();

			while (r.next()) {

				n = r.getInt("count(*)"); // count(*)�� �� attribute�� �� ��������

			}
			if (n == 0) { // 0�̸� �ش� �̸��� ��Ƽ��Ʈ�� �������� �ʴ� ��
				result = 0;
			}

			else { // �ش� �̸��� ��Ƽ��Ʈ�� �����ϸ�
				result = 1;
			}

		} catch (Exception e) {
			System.out.println("Exception : IsExists " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;

	}

	/**
	 * Take the song_sn as a parameter and select all tuple from Song of that
	 * song_sn.
	 * 
	 * @param int sn : song_sn
	 * @return SongDTO
	 */
	public SongDTO getSong(int sn) {
		SongDTO dto = null;
		try {
			getConnection();

			String sql = "SELECT * FROM Song WHERE song_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			ResultSet r = pstmt.executeQuery();

			if (r.next()) {
				int song_sn = r.getInt("song_sn");
				String title = r.getString("title");
				String genre = r.getString("genre");
				int album_sn = r.getInt("album_sn");
				int artist_sn = r.getInt("artist_sn");
				dto = new SongDTO(song_sn, title, genre, album_sn, artist_sn);
			}

		} catch (Exception e) {
			System.out.println("Exception :getSong" + e.getMessage());
		} finally {
			dbClose();
		}
		return dto;

	}

	/**
	 * Select all from Song
	 * 
	 * @return List<SongDTO>
	 */
	public List<SongDTO> getSongList() {
		List<SongDTO> list = new ArrayList<SongDTO>();

		try {
			getConnection();

			String sql = "SELECT * FROM Song";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				int song_sn = r.getInt("song_sn");
				String title = r.getString("title");
				String genre = r.getString("genre");
				int album_sn = r.getInt("album_sn");
				int artist_sn = r.getInt("artist_sn");
				list.add(new SongDTO(song_sn, title, genre, album_sn, artist_sn));
			}

		} catch (Exception e) {
			System.out.println("Exception : getSongList " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	// join select : ��Ƽ��Ʈ, �ٹ� �̸��� ���� �뷡 ����ϱ�

	/**
	 * Take the artist_name and album_name as a parameter and select title,genre
	 * from Song with tha artist_name and album_name using join
	 * 
	 * @param artist_name
	 * @param album_name
	 * @return List<SongDTO>
	 */
	public List<SongDTO> getjoinSongList(String artist_name, String album_name) {
		List<SongDTO> list = new ArrayList<SongDTO>();

		try {
			getConnection();

			String sql = "SELECT title, genre FROM song WHERE album_sn in (SELECT album_sn FROM artist,album WHERE artist.artist_sn=album.artist_sn AND artist.name=? AND album.name=?)";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, artist_name);
			pstmt.setString(2, album_name);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {

				String title = r.getString("title");
				String genre = r.getString("genre");

				list.add(new SongDTO(title, genre));
			}

		} catch (Exception e) {
			System.out.println("Exception : getjoinSongList " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Take song_sn as parameter and delete Song table tuple of that song_sn.
	 */
	public boolean deleteSong(int sn) {
		boolean result = false;
		try {
			getConnection();

			String sql = "DELETE FROM Song WHERE song_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception : deleteSong " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Disconnect with the DB.
	 */
	public void dbClose() {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("Exception : ResultSet close():" + e.getMessage());
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("Exception : PreparedStatement close():" + e.getMessage());
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Exception : Connection  close():" + e.getMessage());
			}
		}

		conn = null;
	}

}
