package DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DataTransfer.AlbumDTO;
import DataTransfer.ArtistDTO;
import DataTransfer.SongDTO;

/**
 * Data Access Object Classes that connect to a database and perform operations
 * such as input , modification, deletion, or query
 * 
 * @author Inryu Shin
 *
 */
public class AlbumDAO {

	private static Connection conn = null;
	private static Statement Stmt = null;
	private static ResultSet rs;
	private PreparedStatement pstmt;

	/**
	 * default constructor
	 */
	public AlbumDAO() {

	}

	/**
	 * Construct a connection using initialized userID, userPW, dbName, url.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private void getConnection() throws ClassNotFoundException, SQLException {
		if (conn == null) { // Connection��ü ������

			String userID = "dbuser";
			String userPW = "dbpwd";
			String dbName = "dbprj";
			String url = "jdbc:mysql://localhost:3306/" + dbName + "?&serverTimezone=UTC";

			conn = DriverManager.getConnection(url, userID, userPW);

		}
	}

	/**
	 * Take AlbumDTO as a parameter and execute insert query.
	 * 
	 * @param AlbumDTO artist
	 * @return boolean
	 */
	public boolean insertAlbum(AlbumDTO album) {

		boolean result = false;

		try {
			getConnection();

			String query = "INSERT INTO Album (name, release_date, artist_sn) VALUES(?,?,?)";

			PreparedStatement pstmt = conn.prepareStatement(query);

			pstmt.setString(1, album.getName());
			pstmt.setString(2, album.getRelease_date());
			pstmt.setInt(3, album.getArtist_sn());

			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception : insertArtist " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Take the album_name of the album as a parameter and check if the data with that
	 * name exists on the album table.
	 * 
	 * @param String album_name
	 * @return 0(not exists) 1(exists)
	 */
	public int IsExists(String album_name) {

		int result = 2;
		int n = 2;

		try {
			getConnection();

			String query = "SELECT count(*) FROM Album WHERE name=?";

			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, album_name);

			ResultSet r = pstmt.executeQuery();

			while (r.next()) {

				n = r.getInt("count(*)"); // count(*)�� �� attribute�� �� ��������

			}
			if (n == 0) { // 0�̸� �ش� �̸��� �ٹ��� �������� �ʴ� ��
				result = 0;
			}

			else { // �ش� �̸��� �ٹ��� �����ϸ�
				result = 1;
			}

		} catch (Exception e) {
			System.out.println("Exception : IsExists " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;

	}
	
	/**
	 * Take the album_sn as a parameter and select all tuple from album of that
	 * album_sn.
	 * 
	 * @param int sn : album_sn
	 * @return AlbumDTO
	 */
	public AlbumDTO getAlbum(int sn) {
		AlbumDTO dto = null;
		try {
			getConnection();

			String sql = "SELECT * FROM Album WHERE album_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			ResultSet r = pstmt.executeQuery();

			if (r.next()) {
				int album_sn = r.getInt("album_sn");
				String name = r.getString("name");
				String release_date = r.getString("release_date");
				int artist_sn = r.getInt("artist_sn");
				dto = new AlbumDTO(album_sn, name, release_date, artist_sn);
			}

		} catch (Exception e) {
			System.out.println("Exception :getAlbum " + e.getMessage());
		} finally {
			dbClose();
		}
		return dto;

	}

	/**
	 * Take the album_name as a parameter and select album_sn from album of that
	 * album name.
	 * 
	 * @param album_name
	 * @return album_sn
	 */
	public int selectSN(String album_name) {

		int album_sn = -1;

		try {
			getConnection();
			String query = "SELECT album_sn FROM Album WHERE name=?";
			PreparedStatement pStmt = conn.prepareStatement(query);
			pStmt.setString(1, album_name);
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				album_sn = rs.getInt("album_sn");
			}
		} catch (Exception e) {
			System.out.println("Exception : selectSN " + e.getMessage());
		} finally {
			dbClose();
		}
		return album_sn;

	}

	/**
	 * Select all from Album
	 * @return List<AlbumDTO>
	 */
	public List<AlbumDTO> getAlbumList() {
		List<AlbumDTO> list = new ArrayList<AlbumDTO>();

		try {
			getConnection();

			String sql = "SELECT * FROM Album";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				int album_sn = r.getInt("album_sn");
				String name = r.getString("name");
				String release_date = r.getString("release_date");
				int artist_sn = r.getInt("artist_sn");
				list.add(new AlbumDTO(album_sn, name, release_date, artist_sn));
			}

		} catch (Exception e) {
			System.out.println("Exception : getAlbumList " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Take album_sn as parameter and delete Album table tuple of that album_sn.
	 */
	public boolean deleteAlbum(int sn) {
		boolean result = false;
		try {
			getConnection();

			String sql = "DELETE FROM Album WHERE album_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception : deleteAlbum " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}


	/**
	 * Disconnect with the DB.
	 */
	public void dbClose() {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("Exception : ResultSet close():" + e.getMessage());
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("Exception : PreparedStatement close():" + e.getMessage());
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Exception : Connection  close():" + e.getMessage());
			}
		}

		conn = null;
	}
}
