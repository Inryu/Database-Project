package DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DataTransfer.ArtistDTO;

/**
 * Data Access Object Classes that connect to a database and perform operations
 * such as input , modification, deletion, or query
 * 
 * @author Inryu Shin
 *
 */
public class ArtistDAO {

	private static Connection conn = null;
	private static Statement Stmt = null;
	private static ResultSet rs;
	private PreparedStatement pstmt;

	/**
	 * default constructor
	 */
	public ArtistDAO() {

	}

	/**
	 * Construct a connection using initialized userID, userPW, dbName, url.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private void getConnection() throws ClassNotFoundException, SQLException {
		if (conn == null) { // Connection��ü ������

			String userID = "dbuser";
			String userPW = "dbpwd";
			String dbName = "dbprj";
			String url = "jdbc:mysql://localhost:3306/" + dbName + "?&serverTimezone=UTC";

			conn = DriverManager.getConnection(url, userID, userPW);

		}
	}

	/**
	 * Take ArtistDTO as a parameter and execute insert query.
	 * 
	 * @param AritstDTO artist
	 * @return boolean
	 */
	public boolean insertArtist(ArtistDTO artist) {

		boolean result = false;

		try {
			getConnection();

			String query = "INSERT INTO Artist (name, debut_date, type, gender) VALUES(?,?,?,?)";

			PreparedStatement pstmt = conn.prepareStatement(query);

			pstmt.setString(1, artist.getName());
			pstmt.setString(2, artist.getDebut_date());
			pstmt.setString(3, artist.getType());
			pstmt.setString(4, artist.getGender());

			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception : insertArtist " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Take the name of the artist as a parameter and check if the data with that
	 * name exists on the artist table.
	 * 
	 * @param String artist_name
	 * @return 0(not exists) 1(exists)
	 */
	public int IsExists(String artist_name) {

		int result = 2;
		int n = 2;

		try {
			getConnection();

			String query = "SELECT count(*) FROM Artist WHERE name=?";

			PreparedStatement pstmt = conn.prepareStatement(query);
			pstmt.setString(1, artist_name);

			ResultSet r = pstmt.executeQuery();

			while (r.next()) {

				n = r.getInt("count(*)"); // count(*)�� �� attribute�� �� ��������

			}
			if (n == 0) { // 0�̸� �ش� �̸��� ��Ƽ��Ʈ�� �������� �ʴ� ��
				result = 0;
			}

			else { // �ش� �̸��� ��Ƽ��Ʈ�� �����ϸ�
				result = 1;
			}

		} catch (Exception e) {
			System.out.println("Exception : IsExists " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;

	}

	/**
	 * Take the artist_sn as a parameter and select all tuple from artist of that
	 * artist's sn.
	 * 
	 * @param int sn : artist_sn
	 * @return ArtistDTO
	 */
	public ArtistDTO getArtist(int sn) {
		ArtistDTO dto = null;
		try {
			getConnection();

			String sql = "SELECT artist_sn, name, debut_date, type, gender FROM Artist WHERE artist_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			ResultSet r = pstmt.executeQuery();

			if (r.next()) {
				int artist_sn = r.getInt("artist_sn");
				String name = r.getString("name");
				String debut_date = r.getString("debut_date");
				String type = r.getString("type");
				String gender = r.getString("gender");
				dto = new ArtistDTO(artist_sn, name, debut_date, type, gender);
			}

		} catch (Exception e) {
			System.out.println("Exception :getArtist " + e.getMessage());
		} finally {
			dbClose();
		}
		return dto;

	}

	/**
	 * Take the artist_name as a parameter and select artist_sn from artist of that
	 * artist's name.
	 * 
	 * @param artist_name
	 * @return artist_sn
	 */
	public int selectSN(String artist_name) {

		int artist_sn = -1;

		try {
			getConnection();
			String query = "SELECT artist_sn FROM Artist WHERE name=?";
			PreparedStatement pStmt = conn.prepareStatement(query);
			pStmt.setString(1, artist_name);
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				artist_sn = rs.getInt("artist_sn");
			}
		} catch (Exception e) {
			System.out.println("Exception : selectSN " + e.getMessage());
		} finally {
			dbClose();
		}
		return artist_sn;

	}

	/**
	 * Select all from Artist.
	 * 
	 * @return List<ArtistDTO>
	 */
	public List<ArtistDTO> getArtistList() {
		List<ArtistDTO> list = new ArrayList<ArtistDTO>();

		try {
			getConnection();

			String sql = "SELECT * FROM ARTIST";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				int artist_sn = r.getInt("artist_sn");
				String name = r.getString("name");
				String debut_date = r.getString("debut_date");
				String type = r.getString("type");
				String gender = r.getString("gender");
				list.add(new ArtistDTO(artist_sn, name, debut_date, type, gender));
			}

		} catch (Exception e) {
			System.out.println("Exception : getArtistList " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Take the type as a parameter and select all from artist of that type.
	 * artist's name.
	 * 
	 * @param type
	 * @return List<ArtistDTO>
	 */
	public List<ArtistDTO> gettypeArtist(String type) {
		List<ArtistDTO> list = new ArrayList<ArtistDTO>();

		try {
			getConnection();

			String sql = "SELECT * FROM ARTIST WHERE type=?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, type);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				int artist_sn = r.getInt("artist_sn");
				String name = r.getString("name");
				String debut_date = r.getString("debut_date");
				String type2 = r.getString("type");
				String gender = r.getString("gender");
				list.add(new ArtistDTO(artist_sn, name, debut_date, type2, gender));
			}

		} catch (Exception e) {
			System.out.println("Exception : gettypeArtist " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Take ArtistDTO as parameter and update Artist table based on
	 * ArtistDTO(parameter)'s member and current_artist_sn
	 * 
	 * @param ArtistDTO
	 * @param current_artist_sn
	 * @return
	 */
	public boolean updateArtist(ArtistDTO dto, int current_artist_sn) {

		boolean result = false;
		try {
			getConnection();

			String sql = "UPDATE Artist SET artist_sn=?,name=?,debut_date=?,type=?,gender=? WHERE artist_sn=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, dto.getArtist_sn());
			pstmt.setString(2, dto.getName());
			pstmt.setString(3, dto.getDebut_date());
			pstmt.setString(4, dto.getType());
			pstmt.setString(5, dto.getGender());
			pstmt.setInt(6, current_artist_sn);

			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception :updateArtist  " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Update artist_sn in Artist and Song table by using transaction.
	 * 
	 * @param current_artist_sn
	 * @param updated_artist_sn
	 * @throws SQLException
	 */
	public void updateTransaction(int current_artist_sn, int updated_artist_sn) throws SQLException {

		try {
			getConnection();
			conn.setAutoCommit(false);

			String sql = "UPDATE Artist SET artist_sn=? WHERE artist_sn=?";
			PreparedStatement pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, updated_artist_sn);
			pstmt.setInt(2, current_artist_sn);
			pstmt.executeUpdate();

			sql = "UPDATE Song SET artist_sn=? WHERE artist_sn=?";

			pstmt.setInt(1, updated_artist_sn);
			pstmt.setInt(2, current_artist_sn);
			pstmt.executeUpdate();

			conn.commit();

		} catch (Exception e) {
			System.out.println("Exception : updateTransaction " + e.getMessage());
		} finally {
			conn.setAutoCommit(true);
			dbClose();
		}
	}

	/**
	 * Take artist_sn as parameter and delete Artist table tuple of that artitst_sn.
	 */
	public boolean deleteArtist(int sn) {
		boolean result = false;
		try {
			getConnection();

			String sql = "DELETE FROM Artist WHERE artist_sn = ?";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, sn);
			int r = pstmt.executeUpdate();

			if (r > 0)
				result = true;

		} catch (Exception e) {
			System.out.println("Exception :deleteArtist " + e.getMessage());
		} finally {
			dbClose();
		}
		return result;
	}

	/**
	 * Disconnect with the DB.
	 */
	public void dbClose() {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("Exception : ResultSet close():" + e.getMessage());
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("Exception : PreparedStatement close():" + e.getMessage());
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Exception : Connection  close():" + e.getMessage());
			}
		}

		conn = null;

	}
}
