package DataAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import DataTransfer.Album_SongDTO;

/**
 * Data Access Object Classes that connect to a database and perform operations
 * such as input , modification, deletion, or query
 * 
 * @author Inryu Shin
 *
 */
public class Album_SongDAO {

	private static Connection conn = null;
	private static Statement Stmt = null;
	private static ResultSet rs;
	private PreparedStatement pstmt;

	/**
	 * default constructor
	 */
	public Album_SongDAO() {

	}

	/**
	 * Construct a connection using initialized userID, userPW, dbName, url.
	 * 
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	private void getConnection() throws ClassNotFoundException, SQLException {
		if (conn == null) { // Connection��ü ������

			String userID = "dbuser";
			String userPW = "dbpwd";
			String dbName = "dbprj";
			String url = "jdbc:mysql://localhost:3306/" + dbName + "?&serverTimezone=UTC";

			conn = DriverManager.getConnection(url, userID, userPW);

		}
	}

	/**
	 * Execute select query using join that is view query of the DB so that use can
	 * see that view table in console.
	 * 
	 * @return List Album_SongDTO
	 */
	public List<Album_SongDTO> getVIEW() {
		List<Album_SongDTO> list = new ArrayList<Album_SongDTO>();

		try {
			getConnection();

			String sql = "SELECT name, title, genre FROM ALBUM, SONG WHERE ALBUM.artist_sn=SONG.artist_sn AND ALBUM.album_sn=SONG.album_sn; ";

			Statement stmt = conn.createStatement();
			ResultSet r = stmt.executeQuery(sql);

			while (r.next()) {
				// int album_sn = r.getInt("album_sn");
				// int artist_sn=r.getInt("artist_sn");
				String name = r.getString("name");
				String title = r.getString("title");
				String genre = r.getString("genre");
				list.add(new Album_SongDTO(name, title, genre));
			}

		} catch (Exception e) {
			System.out.println("Exception : getVIEW " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Take genre as a parameter and select tuple from view of that genre.
	 * 
	 * @param genre album_genre
	 * @return List Album_SongDTO
	 */
	public List<Album_SongDTO> selectGenre(String genre) {
		List<Album_SongDTO> list = new ArrayList<Album_SongDTO>();

		try {
			getConnection();

			String sql = "SELECT album_name, title, genre FROM album_song WHERE genre=?";

			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, genre);
			ResultSet r = pstmt.executeQuery();

			while (r.next()) {
				String name = r.getString("album_name");
				String title = r.getString("title");
				String genre2 = r.getString("genre");
				list.add(new Album_SongDTO(name, title, genre2));
			}

		} catch (Exception e) {
			System.out.println("Exception : selectGenre " + e.getMessage());
		} finally {
			dbClose();
		}

		return list;
	}

	/**
	 * Disconnect with the DB.
	 */
	public void dbClose() {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				System.out.println("Exception : ResultSet close():" + e.getMessage());
			}
		}

		if (pstmt != null) {
			try {
				pstmt.close();
			} catch (SQLException e) {
				System.out.println("Exception : PreparedStatement close():" + e.getMessage());
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				System.out.println("Exception : Connection  close():" + e.getMessage());
			}
		}

		conn = null;

	}
}
