package DataTransfer;

import java.util.Formatter;

/**
 * Object of Song table data transfer (DTO) Columns in the table are treated as
 * member variables.
 * 
 * @author Inryu Shin
 *
 */
public class SongDTO {
	// member variable : columns of table
	private int song_sn;
	private String title;
	private String genre;
	private int album_sn;
	private int artist_sn;

	/**
	 * default constructor
	 */
	public SongDTO() {
	}

	/**
	 * constuctor
	 * 
	 * @param song_sn
	 * @param title
	 * @param genre
	 * @param album_sn
	 * @param artist_sn
	 */
	public SongDTO(int song_sn, String title, String genre, int album_sn, int artist_sn) {
		this.song_sn = song_sn;
		this.title = title;
		this.genre = genre;
		this.album_sn = album_sn;
		this.artist_sn = artist_sn;
	}

	/**
	 * constructor
	 * 
	 * @param title
	 * @param genre
	 * @param album_sn
	 * @param artist_sn
	 */
	public SongDTO(String title, String genre, int album_sn, int artist_sn) {
		this.title = title;
		this.genre = genre;
		this.album_sn = album_sn;
		this.artist_sn = artist_sn;
	}

	/**
	 * constructor
	 * 
	 * @param title
	 * @param genre
	 */
	public SongDTO(String title, String genre) {
		this.title = title;
		this.genre = genre;
	}

	/**
	 *
	 * @return song_sn
	 */
	public int getSong_sn() {
		return song_sn;
	}

	/**
	 * set song_sn
	 * 
	 * @param song_sn
	 */
	public void setSong_sn(int song_sn) {
		this.song_sn = song_sn;
	}

	/**
	 * 
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * set title
	 * 
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * 
	 * @return genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * set genre
	 * 
	 * @param genre
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * 
	 * @return album_sn
	 */
	public int getAlbum_sn() {
		return album_sn;
	}

	/**
	 * set album_sn
	 * 
	 * @param album_sn
	 */
	public void setAlbum_sn(int album_sn) {
		this.album_sn = album_sn;
	}

	/**
	 * 
	 * @return artist_sn
	 */
	public int getArtist_sn() {
		return artist_sn;
	}

	/**
	 * set artist_sn
	 * 
	 * @param artist_sn
	 */
	public void setArtist_sn(int artist_sn) {
		this.artist_sn = artist_sn;
	}

	/**
	 * @Override to String print this class easy to see.
	 */
	public String toString() {
		Formatter fm = new Formatter();
		String Artistinfo = fm.format("%9s\t  %-18s\t%-11s\t%-9s\t%-9s", song_sn, title, genre, album_sn, artist_sn)
				.toString();
		return Artistinfo;
	}

	/**
	 * print this class based on my consol format style.
	 */
	public void printInfo() {
		System.out.println("============================================================================");
		System.out.println("song_sn\t\t title\t\t\tgenre\t  album_sn\tartist_sn");
		System.out.println("============================================================================");
		System.out.println(this.toString());
		System.out.println("============================================================================");
	}

	/**
	 * print this class based on my consol format style.
	 */
	public void printDTO() {
		Formatter fm = new Formatter();
		// System.out.println("============================================================================");
		// System.out.println("title\t\t\t genre\t" );
		// System.out.println("============================================================================");
		System.out.println(fm.format("%30s\t  %30s\t", title, genre));
		// System.out.println("============================================================================");

	}

}
