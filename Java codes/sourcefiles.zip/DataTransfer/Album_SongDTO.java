package DataTransfer;

import java.util.Formatter;

/**
 * Object of Album join Song table data transfer (DTO) Columns in the table are
 * treated as member variables.
 * 
 * @author Inryu Shin
 *
 */
public class Album_SongDTO {

	// member variable : columns of table
	private String name;
	private String title;
	private String genre;

	/**
	 * default_constructor
	 */
	public Album_SongDTO() {

	}

	/**
	 * constructor
	 * 
	 * @param album_name
	 * @param title
	 * @param genre
	 */
	public Album_SongDTO(String album_name, String title, String genre) {
		// this.album_sn=album_sn;
		// this.artist_sn=artist_sn;
		this.name = album_name;
		this.title = title;
		this.genre = genre;
	}

	/**
	 * @Override to String print this class easy to see.
	 */
	public String toString() {
		Formatter fm = new Formatter();
		String Artistinfo = fm.format("%-20s\t  %-25s\t%-25s", name, title, genre).toString();
		return Artistinfo;
	}
}
