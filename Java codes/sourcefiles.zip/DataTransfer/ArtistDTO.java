package DataTransfer;

import java.util.Formatter;

/**
 * Object of Artist table data transfer (DTO) Columns in the table are treated
 * as member variables.
 * 
 * @author Inryu Shin
 *
 */
public class ArtistDTO {

	// member variable : columns of table
	private int artist_sn;
	private String name;
	private String debut_date;
	private String type;
	private String gender;

	/**
	 * default constructor
	 */
	public ArtistDTO() {

	}

	/**
	 * constructor
	 * 
	 * @param artist_sn
	 * @param name
	 * @param debut_date
	 * @param type
	 * @param gender
	 */
	public ArtistDTO(int artist_sn, String name, String debut_date, String type, String gender) {
		this.artist_sn = artist_sn;
		this.name = name;
		this.debut_date = debut_date;
		this.type = type;
		this.gender = gender;

	}

	/**
	 * constructor
	 * 
	 * @param name
	 * @param debut_date
	 * @param type
	 * @param gender
	 */
	public ArtistDTO(String name, String debut_date, String type, String gender) {
		// this.artist_sn=artist_sn;
		this.name = name;
		this.debut_date = debut_date;
		this.type = type;
		this.gender = gender;

	}

	// getter / setter

	/**
	 *
	 * @return artist_sn
	 */
	public int getArtist_sn() {
		return artist_sn;
	}

	/**
	 * set artist_sn
	 * 
	 * @param artist_sn
	 */
	public void setArtist_sn(int artist_sn) {
		this.artist_sn = artist_sn;
	}

	/**
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return dabut_date
	 */
	public String getDebut_date() {
		return debut_date;
	}

	/**
	 * set debut_date
	 * 
	 * @param debut_date
	 */
	public void setDebut_date(String debut_date) {
		this.debut_date = debut_date;
	}

	/**
	 * 
	 * @return type
	 */
	public String getType() {
		return type;
	}

	/**
	 * set type
	 * 
	 * @param type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * 
	 * @return gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * set gender
	 * 
	 * @param gender
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @Override to String print this class easy to see.
	 */
	public String toString() {
		Formatter fm = new Formatter();
		String Artistinfo = fm.format("%9s\t  %-7s\t%-15s\t%-14s\t%-14s", artist_sn, name, debut_date, type, gender)
				.toString();
		return Artistinfo;
	}

	/**
	 * print this class based on my consol format style.
	 */
	public void printInfo() {
		System.out.println("============================================================================");
		System.out.println("artist_sn\t  name \t\tdebut_date\ttype\t\tgender");
		System.out.println("============================================================================");
		System.out.println(this.toString());
		System.out.println("============================================================================");
	}

}
