package DataTransfer;

import java.util.Formatter;

/**
 * Object of Album table data transfer (DTO) Columns in the table are treated as
 * member variables.
 * 
 * @author Inryu Shin
 *
 */
public class AlbumDTO {

	// member variable : columns of table
	private int album_sn;
	private String name;
	private String release_date;
	private int artist_sn;

	/**
	 * default constructor
	 */
	public AlbumDTO() {

	}

	/**
	 * constructor
	 * 
	 * @param album_sn
	 * @param name
	 * @param release_date
	 * @param artist_sn
	 */
	public AlbumDTO(int album_sn, String name, String release_date, int artist_sn) {
		this.album_sn = album_sn;
		this.name = name;
		this.release_date = release_date;
		this.artist_sn = artist_sn;

	}

	/**
	 * constructor
	 * 
	 * @param name
	 * @param release_date
	 * @param artist_sn
	 */
	public AlbumDTO(String name, String release_date, int artist_sn) {
		this.name = name;
		this.release_date = release_date;
		this.artist_sn = artist_sn;

	}

	// getter and setter
	/**
	 * 
	 * @return album_sn
	 */
	public int getAlbum_sn() {
		return album_sn;
	}

	/**
	 * set album_sn
	 * 
	 * @param album_sn
	 */
	public void setAlbum_sn(int album_sn) {
		this.album_sn = album_sn;
	}

	/**
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 
	 * @return release_date
	 */
	public String getRelease_date() {
		return release_date;
	}

	/**
	 * set release_date
	 * 
	 * @param release_date
	 */
	public void setRelease_date(String release_date) {
		this.release_date = release_date;
	}

	/**
	 *
	 * @return artist_sn
	 */
	public int getArtist_sn() {
		return artist_sn;
	}

	/**
	 * set artist_sn
	 * 
	 * @param artist_sn
	 */
	public void setArtist_sn(int artist_sn) {
		this.artist_sn = artist_sn;
	}

	/**
	 * @Override to String print this class easy to see.
	 */
	public String toString() {
		Formatter fm = new Formatter();
		String Artistinfo = fm.format("%9s\t  %-19s\t%-20s\t%-14s", album_sn, name, release_date, artist_sn).toString();
		return Artistinfo;
	}

	/**
	 * print this class based on my consol format style.
	 */
	public void printInfo() {
		System.out.println("============================================================================");
		System.out.println("album_sn\t  name \t\t\trelease_date\tartist_sn\t\t");
		System.out.println("============================================================================");
		System.out.println(this.toString());
		System.out.println("============================================================================");
	}

}
